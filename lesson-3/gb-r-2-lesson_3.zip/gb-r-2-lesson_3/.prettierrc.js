module.exports = {
  // ширина строки
  printWidth: 80,
  // точка с запятой убрать
  semi: false,
  // завершать запятыми строку
  trailingComma: "all",
  // включить круглые скобки вокруг аргумента функции
  arrowParens: "always",
}
